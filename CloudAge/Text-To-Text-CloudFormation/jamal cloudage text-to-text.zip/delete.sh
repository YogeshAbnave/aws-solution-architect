#!/bin/bash

# Set variables
read -p "Enter bucket name to delete: " BUCKET_NAME

# Prompt for region with default
read -p "Enter AWS region (default: us-east-1): " USER_REGION
REGION=${USER_REGION:-us-east-1}

# Prompt for stack name
read -p "Enter the stack name to delete (e.g. CloudAge-GenAI-Stack-1234567890): " STACK_NAME

if [ -z "$STACK_NAME" ]; then
  echo "Error: Stack name is required."
  exit 1
fi

# Verify stack exists
echo "Verifying stack $STACK_NAME exists..."
aws cloudformation describe-stacks --stack-name "$STACK_NAME" > /dev/null 2>&1
if [ $? -ne 0 ]; then
  echo "Error: Stack $STACK_NAME not found."
  exit 1
fi

# Get CloudFront Distribution ID before deleting stack
CLOUDFRONT_DIST_ID=$(aws cloudformation describe-stacks \
  --stack-name "$STACK_NAME" \
  --query "Stacks[0].Outputs[?OutputKey=='CloudFrontDistributionId'].OutputValue" \
  --output text)

# Get SageMaker notebook instance name
NOTEBOOK_NAME=$(aws cloudformation describe-stack-resources \
  --stack-name "$STACK_NAME" \
  --logical-resource-id SageMakerNotebookInstance \
  --query "StackResources[0].PhysicalResourceId" \
  --output text 2>/dev/null || echo "")

# Get SageMaker endpoint name
ENDPOINT_NAME="falcon-7b-instruct-bf16-endpoint"

# Delete SageMaker endpoint if it exists
if aws sagemaker describe-endpoint --endpoint-name "$ENDPOINT_NAME" > /dev/null 2>&1; then
  echo "Deleting SageMaker endpoint $ENDPOINT_NAME..."
  aws sagemaker delete-endpoint --endpoint-name "$ENDPOINT_NAME"
  echo "Waiting for endpoint deletion to complete..."
  aws sagemaker wait endpoint-deleted --endpoint-name "$ENDPOINT_NAME"
  
  # Delete endpoint config
  echo "Deleting endpoint config..."
  aws sagemaker delete-endpoint-config --endpoint-config-name "$ENDPOINT_NAME"
fi

# Delete SageMaker model if it exists
MODEL_NAME="hf-llm-falcon-7b-instruct-bf16-2025-07-30-06-08-50-012"
if aws sagemaker describe-model --model-name "$MODEL_NAME" > /dev/null 2>&1; then
  echo "Deleting SageMaker model $MODEL_NAME..."
  aws sagemaker delete-model --model-name "$MODEL_NAME"
fi

# Delete CloudFormation stack
echo "Deleting CloudFormation stack: $STACK_NAME"
aws cloudformation delete-stack --stack-name "$STACK_NAME"

echo "Waiting for stack deletion to complete..."
aws cloudformation wait stack-delete-complete --stack-name "$STACK_NAME"

# Clean up S3 bucket content (optional - uncomment if you want to delete content)
echo "Cleaning up S3 bucket content..."
aws s3 rm "s3://$BUCKET_NAME/index.html" --region "$REGION"
aws s3 rm "s3://$BUCKET_NAME/cloudage_logo.jpeg" --region "$REGION"
aws s3 rm "s3://$BUCKET_NAME/lambda_function.zip" --region "$REGION"

echo "Removing bucket policy..."
aws s3api delete-bucket-policy --bucket "$BUCKET_NAME" --region "$REGION"

echo "Deleting S3 bucket..."
aws s3api delete-bucket --bucket "$BUCKET_NAME" --region "$REGION"

echo "Resource cleanup complete!"