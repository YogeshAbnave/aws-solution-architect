#!/bin/bash

# Set variables
BUCKET_NAME="cloudage-genai-deployment-$(date +%s)"

# Get current folder path as default
DEFAULT_PATH=$(pwd)

# Prompt with default option
read -p "Enter path to the folder containing deployment files [$DEFAULT_PATH]: " FOLDER_PATH

# Use default if no input provided
FOLDER_PATH=${FOLDER_PATH:-$DEFAULT_PATH}
echo "Using folder path: $FOLDER_PATH"

#Check if Archive.zip exists in the folder
if [ -f "$FOLDER_PATH/Archive.zip" ]; then
  echo "Found Archive.zip, extracting..."
  unzip -o "$FOLDER_PATH/Archive.zip" -d "$FOLDER_PATH"
  
  # Check if unzip was successful
  if [ $? -eq 0 ]; then
    echo "Archive.zip extracted successfully"
  else
    echo "Error: Failed to extract Archive.zip"
    exit 1
  fi
fi

read -p "Enter AWS region (default: us-east-1): " USER_REGION
REGION=${USER_REGION:-us-east-1}

aws s3 mb s3://$BUCKET_NAME --region $REGION

STACK_NAME="CloudAge-GenAI-Stack-$(date +%s)"
echo "Generated stack name: $STACK_NAME"

# Set file paths
TEMPLATE_FILE="$FOLDER_PATH/Latest_GENAI_Script_Prod.yaml"
LAMBDA_ZIP="$FOLDER_PATH/lambda_function.zip"
INDEX_HTML="$FOLDER_PATH/index.html"
LOGO_FILE="$FOLDER_PATH/cloudage_logo.jpeg"

# Upload
aws s3api put-object --bucket $BUCKET_NAME --key index.html --body "$INDEX_HTML" --content-type text/html
aws s3api put-object --bucket $BUCKET_NAME --key cloudage_logo.jpeg --body "$LOGO_FILE" --content-type image/jpeg
aws s3api put-object --bucket $BUCKET_NAME --key lambda_function.zip --body "$LAMBDA_ZIP" --content-type application/zip

# Deploy CloudFormation stack
echo "Deploying CloudFormation stack: $STACK_NAME"
aws cloudformation create-stack \
  --stack-name $STACK_NAME \
  --template-body file://$TEMPLATE_FILE \
  --parameters \
    ParameterKey=LambdaS3Bucket,ParameterValue=$BUCKET_NAME \
    ParameterKey=LambdaS3Key,ParameterValue=lambda_function.zip \
  --capabilities CAPABILITY_IAM

# Wait for stack to complete
echo "Monitoring stack creation..."
aws cloudformation wait stack-create-complete --stack-name $STACK_NAME

# Extract API Gateway URL from CloudFormation stack output
API_URL=$(aws cloudformation describe-stacks --stack-name $STACK_NAME --query "Stacks[0].Outputs[?OutputKey=='ApiGatewayUrl'].OutputValue" --output text)

# Validate that the API URL was retrieved
if [ -z "$API_URL" ]; then
  echo "Error: API Gateway URL not found in stack outputs."
  exit 1
fi

# Construct the full API endpoint URL
FULL_API_URL="${API_URL}/summarize"
echo "New API Gateway URL: $FULL_API_URL"

# Update index.html with the new API URL
echo "Updating index.html with new API URL..."
# Create a backup of the original file
cp "$INDEX_HTML" "$INDEX_HTML.backup"

# Update the API URL in index.html
# This looks for patterns like https://[alphanumeric].execute-api.[region].amazonaws.com/prod/summarize
sed -i.tmp -E "s|https://[a-zA-Z0-9]+\.execute-api\.[a-zA-Z0-9-]+\.amazonaws\.com/[a-zA-Z0-9]+/summarize|$FULL_API_URL|g" "$INDEX_HTML"

# Remove the temporary file created by sed
rm -f "$INDEX_HTML.tmp"

echo "index.html updated successfully."

# Extract CloudFront Distribution ID from CloudFormation stack output
CLOUDFRONT_DIST_ID=$(aws cloudformation describe-stacks \
  --stack-name "$STACK_NAME" \
  --query "Stacks[0].Outputs[?OutputKey=='CloudFrontDistributionId'].OutputValue" \
  --output text)

# Validate that the distribution ID was retrieved
if [ -z "$CLOUDFRONT_DIST_ID" ]; then
  echo "Error: CloudFront Distribution ID not found in stack outputs."
  exit 1
fi

# Get AWS Account ID
ACCOUNT_ID=$(aws sts get-caller-identity --query "Account" --output text)

# Validate account ID
if [ -z "$ACCOUNT_ID" ]; then
  echo "Error: Unable to retrieve AWS account ID."
  exit 1
fi

# Construct and attach the S3 bucket policy for CloudFront OAC
echo "Attaching S3 bucket policy for CloudFront OAC..."
cat > policy.json <<EOF
{
  "Version": "2008-10-17",
  "Id": "PolicyForCloudFrontPrivateContent",
  "Statement": [
    {
      "Sid": "AllowCloudFrontServicePrincipal",
      "Effect": "Allow",
      "Principal": {
        "Service": "cloudfront.amazonaws.com"
      },
      "Action": "s3:*",
      "Resource": "arn:aws:s3:::$BUCKET_NAME/*",
      "Condition": {
        "StringEquals": {
          "AWS:SourceArn": "arn:aws:cloudfront::$ACCOUNT_ID:distribution/$CLOUDFRONT_DIST_ID"
        }
      }
    }
  ]
}
EOF

aws s3api put-bucket-policy --bucket "$BUCKET_NAME" --policy file://policy.json
echo "Bucket policy applied successfully."

# Re-upload index.html to S3
echo "Re-uploading updated index.html to S3..."
aws s3api put-object --bucket $BUCKET_NAME --key index.html --body "$INDEX_HTML" --content-type text/html

# Invalidate CloudFront cache for all paths
echo "Creating CloudFront invalidation for all paths..."
INVALIDATION_ID=$(aws cloudfront create-invalidation \
  --distribution-id "$CLOUDFRONT_DIST_ID" \
  --paths "/*" \
  --query "Invalidation.Id" \
  --output text)

echo "Invalidation request submitted. ID: $INVALIDATION_ID"

# Display Outputs
echo "Stack creation complete. Outputs:"
aws cloudformation describe-stacks --stack-name $STACK_NAME --query "Stacks[0].Outputs" --output table

echo ""
echo "API Gateway URL:"
echo "$FULL_API_URL"

echo ""
echo "Frontend URL:"
CLOUDFRONT_URL=$(aws cloudformation describe-stacks --stack-name $STACK_NAME --query "Stacks[0].Outputs[?OutputKey=='CloudFrontDistributionDomain'].OutputValue" --output text)
echo "$CLOUDFRONT_URL"

echo "Deployment complete!"

# Clean up temporary files
rm -f policy.json
rm -f "$INDEX_HTML.backup"